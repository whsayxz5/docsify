# 邮储专用

**一、解决问题**

![1626769516527285.png](../media/1626769516527285.png)

##### 二、操作姿势

👉**刷卡：**[合利宝](tool/hlb.md)/[安心付](tool/axf.md)/[恒信通](tool/hxt.md)/[云付宝](tool/yfb.md)，小额测试（[:link: 点此查询](https://www.zjkmkj.com/Weixin/index)）有分直接大额

👉**微信支付宝：**[付惠码](tool/fhm.md)/[易收钱](tool/ysq.md)/[拉卡拉](tool/lkl.md)，直接刷
